package pandumain;
import java.util.Scanner;

public class alat {
   static Scanner alat = new Scanner(System.in);

    String nama(String nam) {
     System.out.print("Masukkan Nama Alat:");
     nam = alat.next();
     return nam;
    }

    String merk(String mer) {
     System.out.print("Masukkan Merk:");
     mer = alat.next();
     return mer;
    }

    double hargaBeli(double har) {
     System.out.print("Masukkan Harga:");
     har = alat.nextDouble();
     return har;
    }  
}
