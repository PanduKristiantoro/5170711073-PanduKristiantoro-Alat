package pandumain;
import java.util.Scanner;

public class AlatKesehatan extends alat {
    static Scanner alat = new Scanner(System.in);
    String jenis(String jakes) {
        System.out.print("Masukkan Jenis:");
        jakes = alat.next();
        return jakes;
    }
    String manfaat(String manf) {
        System.out.print("Masukkan Manfaat:");
        manf = alat.next();
        return manf;
    }

    
}
