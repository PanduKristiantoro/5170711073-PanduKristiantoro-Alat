package pandumain;
import java.util.Scanner;

public class AlatTulis extends alat{
    static Scanner alat = new Scanner(System.in);

    String fungsi(String fung) {
     System.out.print(" Fungsi:");
     fung = alat.next();
     return fung;
    }

    int dimensi(int D) {
     int p, l;
     System.out.print(" Dimensi:");
     p = alat.nextInt();
     l = alat.nextInt();
     return D;
    } 

    
}
