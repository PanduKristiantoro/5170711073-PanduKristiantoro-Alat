package pandumain;
import java.util.Scanner;

public class Alatmandi extends alat  {
  static Scanner alat = new Scanner(System.in);

    String wujud(String color) {
     System.out.print("Masukkan Warna:");
     color = alat.next();
     return color;
    }

    String warna(String wuj) {
     System.out.print("Masukkan Wujud:");
     wuj = alat.next();
     return wuj;
    } 
}
